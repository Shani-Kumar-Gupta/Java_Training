package com.example.springbootmanagementexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootManagementExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
